#!/usr/bin/env python3
"""يجهّز مشروع أندرويد الذي أنشأه flutter create:
- يولّد lib/firebase_options.dart من google-services.json
- يضيف الصلاحيات واسم التطبيق ويرفع minSdk
- يضبط توقيع الإصدار بملف diwan.jks الثابت
- ينسخ أيقونة التطبيق
usage: prepare.py <app_dir> <google-services.json> <tool_dir>
"""
import json, os, re, shutil, sys

app, gs, tool = sys.argv[1], sys.argv[2], sys.argv[3]
android = os.path.join(app, 'android')


def fail(msg):
    print('ERROR:', msg)
    sys.exit(1)


# ── 1) firebase_options.dart ──
j = json.load(open(gs, encoding='utf-8'))
pi = j['project_info']
client = None
for c in j['client']:
    if c['client_info']['android_client_info']['package_name'] == 'xyz.diwaniq.app':
        client = c
        break
if client is None:
    fail('google-services.json لا يحتوي تطبيقاً باسم الحزمة xyz.diwaniq.app')
api_key = client['api_key'][0]['current_key']
app_id = client['client_info']['mobilesdk_app_id']
web_client = ''
for oc in client.get('oauth_client', []):
    if oc.get('client_type') == 3:
        web_client = oc['client_id']
bucket = pi.get('storage_bucket', '')
dart = f"""import 'package:firebase_core/firebase_core.dart';

const FirebaseOptions kFirebaseOptions = FirebaseOptions(
  apiKey: '{api_key}',
  appId: '{app_id}',
  messagingSenderId: '{pi['project_number']}',
  projectId: '{pi['project_id']}',
  storageBucket: '{bucket}',
);

const String kWebClientId = '{web_client}';
"""
open(os.path.join(app, 'lib', 'firebase_options.dart'), 'w', encoding='utf-8').write(dart)
if not web_client:
    print('WARNING: لا يوجد web client في google-services.json — فعّل Google في Authentication وأضف SHA-1 ثم نزّل الملف من جديد')

# ── 2) AndroidManifest ──
mf = os.path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml')
m = open(mf, encoding='utf-8').read()
perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
"""
if 'android.permission.INTERNET' not in m:
    m = m.replace('<application', perms + '    <application', 1)
m = re.sub(r'android:label="[^"]*"', 'android:label="ديوان"', m, count=1)
open(mf, 'w', encoding='utf-8').write(m)

# ── 3) Gradle: minSdk + التوقيع ──
gp = None
kts = False
for name in ('build.gradle', 'build.gradle.kts'):
    p = os.path.join(android, 'app', name)
    if os.path.exists(p):
        gp, kts = p, name.endswith('.kts')
        break
if gp is None:
    fail('لم أجد android/app/build.gradle')
g = open(gp, encoding='utf-8').read()

g, n1 = re.subn(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion', 'minSdk = 23' if kts else 'minSdkVersion 23', g)
if n1 == 0:
    fail('لم أجد سطر minSdk')

shutil.copy(os.path.join(tool, 'diwan.jks'), os.path.join(android, 'diwan.jks'))
shutil.copy(os.path.join(tool, 'key.properties'), os.path.join(android, 'key.properties'))

if kts:
    imports = "import java.util.Properties\nimport java.io.FileInputStream\n\n"
    header = """val keystoreProperties = Properties()
keystoreProperties.load(FileInputStream(rootProject.file("key.properties")))

"""
    sign = """    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = rootProject.file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
"""
    g = imports + g
    g, n2 = re.subn(r'android\s*\{', lambda m: header + 'android {\n' + sign, g, count=1)
    g, n3 = re.subn(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
                    'signingConfig = signingConfigs.getByName("release")', g)
else:
    header = """def keystoreProperties = new Properties()
keystoreProperties.load(new FileInputStream(rootProject.file("key.properties")))

"""
    sign = """    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile rootProject.file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
"""
    g, n2 = re.subn(r'android\s*\{', lambda m: header + 'android {\n' + sign, g, count=1)
    g, n3 = re.subn(r'signingConfig\s+signingConfigs\.debug', 'signingConfig signingConfigs.release', g)
if n2 == 0 or n3 == 0:
    fail('تعذّر ضبط التوقيع في ' + gp)
open(gp, 'w', encoding='utf-8').write(g)

# ── 4) الأيقونة ──
for d in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
    dst = os.path.join(android, 'app', 'src', 'main', 'res', 'mipmap-' + d)
    os.makedirs(dst, exist_ok=True)
    shutil.copy(os.path.join(tool, 'icons', d + '.png'), os.path.join(dst, 'ic_launcher.png'))

print('prepare OK:', app_id)
