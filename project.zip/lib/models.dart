import 'dart:math' as math;

double toD(dynamic v, [double def = 0]) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.trim()) ?? def;
  return def;
}

int toI(dynamic v, [int def = 0]) => toD(v, def.toDouble()).round();

String toS(dynamic v, [String def = '']) => v == null ? def : v.toString();

DateTime? toDate(dynamic v) {
  if (v == null) return null;
  try {
    // Timestamp من Firestore
    final dynamic d = (v as dynamic).toDate();
    if (d is DateTime) return d;
  } catch (_) {}
  if (v is DateTime) return v;
  if (v is num) return DateTime.fromMillisecondsSinceEpoch(v.toInt());
  if (v is String) return DateTime.tryParse(v);
  return null;
}

class Dish {
  final String name;
  final String desc;
  final String emoji;
  final String image;
  final String category;
  final int price;
  final bool available;

  Dish({
    required this.name,
    required this.desc,
    required this.emoji,
    required this.image,
    required this.category,
    required this.price,
    required this.available,
  });

  factory Dish.fromMap(Map<String, dynamic> m) => Dish(
        name: toS(m['name']),
        desc: toS(m['desc']),
        emoji: toS(m['emoji'], '🍽️'),
        image: toS(m['imgBase64'] ?? m['imageUrl'] ?? m['img']),
        category: toS(m['category']),
        price: toI(m['price']),
        available: m['available'] != false,
      );
}

class MenuCategory {
  final String id;
  final String name;
  MenuCategory(this.id, this.name);
}

class Restaurant {
  final String id;
  final Map<String, dynamic> raw;
  Restaurant(this.id, this.raw);

  String get name => toS(raw['name'], 'مطعم');
  String get emoji => toS(raw['emoji'], '🍽️');
  String get image => toS(raw['imageUrl'] ?? raw['imageBase64']);
  String get category => toS(raw['category']);
  String get area => toS(raw['area']);
  String get address => toS(raw['address']);
  String get phone => toS(raw['phone']);
  String get time => toS(raw['time'], '30-45');
  double get rating => toD(raw['avgRating'] ?? raw['rating']);
  int get ratingCount => toI(raw['ratingCount']);

  double? get lat {
    final v = toD(raw['lat'] ?? raw['restLat']);
    return v == 0 ? null : v;
  }

  double? get lng {
    final v = toD(raw['lng'] ?? raw['restLng']);
    return v == 0 ? null : v;
  }

  List<Dish> get items {
    final l = raw['items'];
    if (l is! List) return [];
    final out = <Dish>[];
    for (final e in l) {
      if (e is Map) out.add(Dish.fromMap(Map<String, dynamic>.from(e)));
    }
    return out;
  }

  List<MenuCategory> get categories {
    final l = raw['categories'];
    if (l is! List) return [];
    final out = <MenuCategory>[];
    for (final e in l) {
      if (e is Map) {
        out.add(MenuCategory(toS(e['id']), toS(e['name'])));
      }
    }
    return out;
  }

  /// نفس منطق تطبيق الويب (_applyRestHoursStatus)
  bool get isOpenNow {
    final open = toS(raw['openTime']);
    final close = toS(raw['closeTime']);
    if (open.isEmpty || close.isEmpty) return true;
    final now = DateTime.now();
    final dayNum = now.weekday % 7; // الأحد = 0 ... السبت = 6
    const names = {
      'sun': 0, 'mon': 1, 'tue': 2, 'wed': 3, 'thu': 4, 'fri': 5, 'sat': 6
    };
    final wd = raw['workDays'];
    if (wd is List && wd.isNotEmpty) {
      final nums = wd.map<int>((d) {
        if (d is num) return d.toInt();
        return names[d.toString()] ?? -1;
      }).toList();
      if (!nums.contains(dayNum)) return false;
    }
    int mins(String s) {
      final p = s.split(':');
      if (p.length < 2) return 0;
      return (int.tryParse(p[0]) ?? 0) * 60 + (int.tryParse(p[1]) ?? 0);
    }

    final nowM = now.hour * 60 + now.minute;
    final o = mins(open);
    final c = mins(close);
    if (c > o) return nowM >= o && nowM < c;
    return nowM >= o || nowM < c;
  }
}

class CartLine {
  final Dish item;
  int qty;
  CartLine(this.item, this.qty);
}

class Coupon {
  final String code;
  final String type; // percent | fixed | free_delivery
  final double value;
  final int maxDiscount;
  final int minOrder;
  final String restId;
  Coupon({
    required this.code,
    required this.type,
    required this.value,
    required this.maxDiscount,
    required this.minOrder,
    required this.restId,
  });

  int amount(int subtotal, int fee) {
    double d = 0;
    if (type == 'percent') {
      d = (subtotal * math.min(100, math.max(0, value)) / 100).floorToDouble();
    } else if (type == 'fixed') {
      d = value.floorToDouble();
    } else if (type == 'free_delivery') {
      d = fee.toDouble();
    }
    if (maxDiscount > 0 && type != 'free_delivery') {
      d = math.min(d, maxDiscount.toDouble());
    }
    final cap = type == 'free_delivery' ? fee : subtotal;
    return math.max(0, math.min(d.toInt(), cap));
  }
}

/// حالة الطلب (للعرض فقط)
class StatusInfo {
  final String text;
  final int step; // 0..3
  final bool done;
  final bool cancelled;
  StatusInfo(this.text, this.step, {this.done = false, this.cancelled = false});
}

StatusInfo statusOf(Map<String, dynamic> o) {
  final st = toS(o['status'], 'waiting');
  final rs = toS(o['restStatus']);
  final taxi = o['isTaxi'] == true || o['type'] == 'taxi';
  if (st == 'cancelled' || st == 'rejected' || rs == 'rejected') {
    return StatusInfo(
        rs == 'rejected' ? '❌ رفض المطعم الطلب' : '❌ ملغي', 0,
        cancelled: true);
  }
  if (taxi) {
    switch (st) {
      case 'taxi_accepted':
        return StatusInfo('✅ السائق قبل طلبك', 1);
      case 'taxi_arrived':
        return StatusInfo('📍 السائق في موقعك', 2);
      case 'taxi_delivered':
      case 'completed':
        return StatusInfo('🏁 وصلت وجهتك', 3, done: true);
      default:
        return StatusInfo('⏳ قيد الانتظار', 0);
    }
  }
  switch (st) {
    case 'delivered':
    case 'completed':
      return StatusInfo('✅ تم التسليم', 3, done: true);
    case 'pickup':
      return StatusInfo('📦 تم الاستلام', 2);
    case 'on_way':
      return StatusInfo('🛵 في الطريق', 2);
    case 'ready':
      return StatusInfo('📦 الطلب جاهز', 1);
    case 'preparing':
      return StatusInfo('👨‍🍳 جاري التجهيز', 1);
    case 'driver_accepted':
    case 'accepted':
      return StatusInfo('🛵 السائق قادم للمطعم', 1);
    default:
      if (rs == 'accepted') return StatusInfo('✅ المطعم قبل طلبك', 1);
      return StatusInfo('⏳ قيد الانتظار', 0);
  }
}
