import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../common.dart';
import '../models.dart';
import '../services.dart';

class OrdersTab extends StatefulWidget {
  const OrdersTab({super.key});

  @override
  State<OrdersTab> createState() => _OrdersTabState();
}

class _OrdersTabState extends State<OrdersTab> {
  late final Stream<List<Map<String, dynamic>>> _stream;

  @override
  void initState() {
    super.initState();
    _stream = Orders.mine();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('تعذّر تحميل الطلبات\n${snap.error}', textAlign: TextAlign.center));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final list = snap.data!.where((o) => o['deletedAccount'] != true).toList();
        if (list.isEmpty) return const Center(child: Text('لا توجد طلبات بعد'));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: list.length,
          itemBuilder: (_, i) {
            final o = list[i];
            final st = statusOf(o);
            final taxi = o['isTaxi'] == true || o['type'] == 'taxi';
            final t = toDate(o['createdAt']);
            return Card(
              child: ListTile(
                leading: Text(taxi ? '🚕' : '🏪', style: const TextStyle(fontSize: 28)),
                title: Text(toS(o['restName'], taxi ? 'تكسي' : 'طلب')),
                subtitle: Text(
                  '${st.text}\n${fmt(toD(o['total']))} د.ع'
                  '${t != null ? '  ·  ${t.day}/${t.month} ${t.hour}:${t.minute.toString().padLeft(2, '0')}' : ''}',
                ),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => TrackScreen(orderId: toS(o['id'])))),
              ),
            );
          },
        );
      },
    );
  }
}

// ───────── تتبع الطلب ─────────
class TrackScreen extends StatefulWidget {
  final String orderId;
  const TrackScreen({super.key, required this.orderId});

  @override
  State<TrackScreen> createState() => _TrackScreenState();
}

class _TrackScreenState extends State<TrackScreen> {
  late final Stream<Map<String, dynamic>?> _stream;
  bool _rated = false;

  @override
  void initState() {
    super.initState();
    _stream = Orders.one(widget.orderId);
    SharedPreferences.getInstance().then((sp) {
      if (!mounted) return;
      setState(() => _rated = sp.getBool('rated_${widget.orderId}') ?? false);
    });
  }

  bool _canCancel(Map<String, dynamic> o) {
    final st = toS(o['status'], 'waiting');
    return const [
      'waiting',
      'driver_accepted',
      'accepted',
      'taxi_accepted',
      'rest_accepted',
      'preparing',
      'ready'
    ].contains(st);
  }

  Future<void> _cancel() async {
    final ok = await confirmDialog(context, 'إلغاء الطلب', 'هل تريد إلغاء هذا الطلب؟', ok: 'إلغاء الطلب');
    if (!ok) return;
    try {
      await Orders.cancel(widget.orderId);
    } catch (_) {
      if (mounted) toast(context, 'تعذّر إلغاء الطلب');
    }
  }

  Future<void> _rate(Map<String, dynamic> o) async {
    var stars = 5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('قيّم المطعم'),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: List.generate(
              5,
              (i) => IconButton(
                onPressed: () => setS(() => stars = i + 1),
                icon: Icon(i < stars ? Icons.star : Icons.star_border,
                    color: Colors.amber, size: 32),
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لاحقاً')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إرسال')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final done = await Orders.rate(
        toS(o['restId']), toS(o['restName']), widget.orderId, stars);
    if (!mounted) return;
    if (done) {
      final sp = await SharedPreferences.getInstance();
      await sp.setBool('rated_${widget.orderId}', true);
      if (mounted) setState(() => _rated = true);
      if (mounted) toast(context, 'شكراً لتقييمك ⭐');
    } else {
      toast(context, 'تعذّر إرسال التقييم');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تتبع الطلب')),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('تعذّر التحميل\n${snap.error}'));
          if (!snap.hasData) {
            return snap.connectionState == ConnectionState.waiting
                ? const Center(child: CircularProgressIndicator())
                : const Center(child: Text('الطلب غير موجود'));
          }
          final o = snap.data!;
          final st = statusOf(o);
          final taxi = o['isTaxi'] == true || o['type'] == 'taxi';
          final icons = taxi
              ? ['⏳', '🚕', '📍', '🏁']
              : ['⏳', '🏪', '🛵', '✅'];
          final items = (o['items'] is List) ? (o['items'] as List) : const [];
          final dLat = toD(o['driverLat']), dLng = toD(o['driverLng']);
          final hasDriverPos = dLat != 0 && dLng != 0 && !st.done && !st.cancelled;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Center(
                child: Text(st.text,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 16),
              if (!st.cancelled)
                Row(
                  children: List.generate(4, (i) {
                    final on = i <= st.step;
                    return Expanded(
                      child: Column(
                        children: [
                          CircleAvatar(
                            backgroundColor: on ? kPrimary : Colors.black12,
                            child: Text(icons[i]),
                          ),
                          const SizedBox(height: 4),
                          Container(height: 3, color: on ? kPrimary : Colors.black12),
                        ],
                      ),
                    );
                  }),
                ),
              const SizedBox(height: 16),
              if (hasDriverPos)
                SizedBox(
                  height: 220,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: FlutterMap(
                      options: MapOptions(initialCenter: LatLng(dLat, dLng), initialZoom: 15),
                      children: [
                        TileLayer(
                          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'xyz.diwaniq.app',
                        ),
                        MarkerLayer(markers: [
                          Marker(
                            point: LatLng(dLat, dLng),
                            width: 44,
                            height: 44,
                            child: const Text('🛵', style: TextStyle(fontSize: 32)),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(toS(o['restName'], taxi ? 'تكسي' : 'طلب'),
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 6),
                      if (taxi) ...[
                        Text('من: ${toS(o['from'])}'),
                        Text('إلى: ${toS(o['to'])}'),
                      ] else
                        ...items.whereType<Map>().map((e) =>
                            Text('${toS(e['emoji'])} ${toS(e['name'])} ×${toS(e['qty'], '1')}')),
                      const Divider(),
                      if (!taxi && toD(o['deliveryFee']) > 0)
                        Text('التوصيل: ${fmt(toD(o['deliveryFee']))} د.ع'),
                      if (toD(o['discount']) > 0)
                        Text('الخصم: - ${fmt(toD(o['discount']))} د.ع'),
                      Text('الإجمالي: ${fmt(toD(o['total']))} د.ع',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              if (_canCancel(o) && !st.cancelled && !st.done)
                OutlinedButton(
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                  onPressed: _cancel,
                  child: const Text('إلغاء الطلب'),
                ),
              if (st.done && !taxi && !_rated && toS(o['restId']).isNotEmpty)
                FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: kPrimary),
                  onPressed: () => _rate(o),
                  child: const Text('⭐ قيّم المطعم'),
                ),
            ],
          );
        },
      ),
    );
  }
}
