import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../common.dart';
import '../models.dart';
import '../services.dart';
import 'orders_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _addr = TextEditingController();
  final _notes = TextEditingController();
  final _coupon = TextEditingController();

  LatLng? _pin;
  int _fee = kDeliveryMin;
  double? _km;
  bool _feeBusy = false;
  bool _placing = false;
  String? _couponMsg;

  Cart get cart => Cart.instance;

  @override
  void initState() {
    super.initState();
    Profile.load().then((p) {
      if (!mounted) return;
      _name.text = p.$1;
      _phone.text = p.$2;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _addr.dispose();
    _notes.dispose();
    _coupon.dispose();
    super.dispose();
  }

  Future<void> _setPin(LatLng p) async {
    if (!inZone(p.latitude, p.longitude)) {
      setState(() => _pin = null);
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('خارج منطقة العمل'),
            content: const Text(
                'نعتذر، موقع التوصيل خارج منطقة العمل. خدمة توصيل الطعام متاحة داخل محافظة الديوانية فقط.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))
            ],
          ),
        );
      }
      return;
    }
    setState(() {
      _pin = p;
      _feeBusy = true;
    });
    final r = cart.restaurant;
    final rl = r?.lat, rg = r?.lng;
    final from = (rl != null && rg != null) ? LatLng(rl, rg) : kCenter;
    final km = await roadDistanceKm(from, p);
    if (!mounted) return;
    setState(() {
      _km = km;
      _fee = deliveryFeeForKm(km);
      _feeBusy = false;
    });
    if (_addr.text.trim().isEmpty) {
      final name = await reverseGeocode(p);
      if (mounted && _addr.text.trim().isEmpty) _addr.text = name;
    }
  }

  Future<void> _useGps() async {
    final p = await currentLocation();
    if (!mounted) return;
    if (p == null) {
      toast(context, 'تعذّر تحديد موقعك، فعّل الموقع أو اختر من الخريطة');
      return;
    }
    await _setPin(p);
  }

  Future<void> _pickOnMap() async {
    final p = await Navigator.push<LatLng>(
      context,
      MaterialPageRoute(
          builder: (_) => MapPicker(title: 'موقع التوصيل', initial: _pin ?? kCenter)),
    );
    if (p != null) await _setPin(p);
  }

  Future<void> _applyCoupon() async {
    if (cart.coupon != null) {
      cart.removeCoupon();
      _coupon.clear();
      setState(() => _couponMsg = null);
      return;
    }
    final e = await cart.applyCoupon(_coupon.text);
    if (!mounted) return;
    setState(() => _couponMsg = e ?? '✅ تم تطبيق الخصم');
  }

  Future<void> _place() async {
    final name = _name.text.trim();
    final phone = _phone.text.trim();
    final addr = _addr.text.trim();
    if (name.isEmpty || addr.isEmpty || phone.isEmpty) {
      toast(context, '⚠️ يرجى إدخال الاسم والعنوان والهاتف');
      return;
    }
    if (phone.replaceAll(RegExp(r'\D'), '').length < 7) {
      toast(context, '⚠️ رقم الهاتف غير صحيح');
      return;
    }
    final pin = _pin;
    if (pin == null) {
      toast(context, '📍 حدّد موقع التوصيل على الخريطة أولاً');
      return;
    }
    final r = cart.restaurant;
    if (r == null || cart.isEmpty) {
      toast(context, '⚠️ السلة فارغة');
      return;
    }
    if (!r.isOpenNow) {
      toast(context, '🔴 المطعم مغلق حالياً');
      return;
    }
    setState(() => _placing = true);
    await Profile.save(name, phone);

    final sub = cart.subtotal;
    final cp = cart.coupon;
    final discount = cp == null ? 0 : cp.amount(sub, _fee);
    final total = (sub + _fee - discount).clamp(0, 1 << 40);
    final items = cart.lines
        .map((l) => {
              'name': l.item.name,
              'price': l.item.price,
              'emoji': l.item.emoji,
              'desc': l.item.desc,
              'category': l.item.category,
              'qty': l.qty,
              'restId': r.id,
              'restName': r.name,
            })
        .toList();

    final od = <String, dynamic>{
      'type': 'food',
      'items': items,
      'address': addr,
      'phone': phone,
      'city': 'الديوانية',
      'location': {'lat': pin.latitude, 'lng': pin.longitude},
      'total': total,
      'notes': _notes.text.trim(),
      'foodSubtotal': sub,
      'deliveryFee': _fee,
      if (discount > 0) 'discount': discount,
      if (discount > 0 && cp != null) 'discountCode': cp.code,
      'restName': r.name,
      'restId': r.id,
      'restPhone': r.phone,
      'restLat': r.lat ?? kCenter.latitude,
      'restLng': r.lng ?? kCenter.longitude,
      'restAddr': r.address.isEmpty ? 'الديوانية' : r.address,
      'custLat': pin.latitude,
      'custLng': pin.longitude,
      'lat': pin.latitude,
      'lng': pin.longitude,
      'customer': name,
      'customerPhone': phone,
      'status': 'waiting',
      'restStatus': 'pending',
    };
    final id = await Orders.save(od);
    if (!mounted) return;
    setState(() => _placing = false);
    if (id == null) {
      toast(context, '❌ تعذّر إرسال الطلب، تأكد من الاتصال وحاول مجدداً');
      return;
    }
    cart.clear();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => TrackScreen(orderId: id)));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: cart,
      builder: (context, _) {
        if (cart.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: const Text('السلة')),
            body: const Center(child: Text('🛒 سلتك فارغة')),
          );
        }
        final sub = cart.subtotal;
        final cp = cart.coupon;
        final discount = cp == null ? 0 : cp.amount(sub, _fee);
        final total = sub + _fee - discount;
        return Scaffold(
          appBar: AppBar(title: Text('سلة ${cart.restaurant?.name ?? ''}')),
          body: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              ...cart.lines.map((l) => Card(
                    child: ListTile(
                      leading: Pic(src: l.item.image, emoji: l.item.emoji, size: 48, radius: 10),
                      title: Text(l.item.name),
                      subtitle: Text('${fmt(l.item.price * l.qty)} د.ع'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                              onPressed: () => cart.dec(l),
                              icon: const Icon(Icons.remove_circle_outline)),
                          Text('${l.qty}',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                          IconButton(
                              onPressed: () => cart.inc(l),
                              icon: const Icon(Icons.add_circle_outline)),
                        ],
                      ),
                    ),
                  )),
              const SizedBox(height: 10),
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم')),
              const SizedBox(height: 10),
              TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _addr,
                decoration: const InputDecoration(labelText: 'العنوان (المنطقة / الشارع / أقرب نقطة دالة)'),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _useGps,
                      icon: const Icon(Icons.my_location),
                      label: const Text('موقعي'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickOnMap,
                      icon: const Icon(Icons.map),
                      label: const Text('من الخريطة'),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  _pin == null
                      ? '📍 حدّد موقع التوصيل ليُحسب سعر التوصيل بدقة'
                      : '✅ تم تحديد الموقع${_km != null ? ' (${_km!.toStringAsFixed(1)} كم)' : ''}',
                  style: const TextStyle(fontSize: 13, color: Colors.black54),
                ),
              ),
              TextField(
                controller: _notes,
                decoration: const InputDecoration(labelText: 'ملاحظات (اختياري)'),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _coupon,
                      enabled: cp == null,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(labelText: 'كود الخصم', isDense: true),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: kPrimary),
                    onPressed: _applyCoupon,
                    child: Text(cp == null ? 'تطبيق' : 'إزالة'),
                  ),
                ],
              ),
              if (_couponMsg != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(_couponMsg!, style: const TextStyle(fontSize: 12)),
                ),
              const Divider(height: 28),
              _row('المجموع', '${fmt(sub)} د.ع'),
              _row('التوصيل', _feeBusy ? '⏳ ...' : '${fmt(_fee)} د.ع'),
              if (discount > 0) _row('الخصم (${cp?.code})', '- ${fmt(discount)} د.ع'),
              _row('الإجمالي', '${fmt(total < 0 ? 0 : total)} د.ع', bold: true),
              const SizedBox(height: 16),
              FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: kPrimary, padding: const EdgeInsets.all(14)),
                onPressed: (_placing || _feeBusy) ? null : _place,
                child: _placing
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('تأكيد الطلب (الدفع نقداً عند الاستلام)',
                        style: TextStyle(fontSize: 16)),
              ),
              const SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }

  Widget _row(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(a, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
            Text(b,
                style: TextStyle(
                    fontWeight: bold ? FontWeight.bold : FontWeight.normal,
                    fontSize: bold ? 17 : 14)),
          ],
        ),
      );
}
