import 'package:flutter/material.dart';

import '../common.dart';
import '../models.dart';
import '../services.dart';
import 'cart_screen.dart';

class RestaurantScreen extends StatelessWidget {
  final Restaurant r;
  const RestaurantScreen(this.r, {super.key});

  Future<void> _add(BuildContext context, Dish d) async {
    final cart = Cart.instance;
    if (!r.isOpenNow) {
      toast(context, '🔴 المطعم مغلق حالياً، لا يمكن الطلب');
      return;
    }
    if (!d.available) {
      toast(context, '🔴 هذا الطبق نفذ حالياً');
      return;
    }
    if (!cart.canAddFrom(r)) {
      final ok = await confirmDialog(
        context,
        'سلة من مطعم آخر',
        'سلتك تحتوي أصنافاً من ${cart.restaurant?.name ?? 'مطعم آخر'}. هل تريد تفريغها والبدء من ${r.name}؟',
        ok: 'تفريغ والبدء',
      );
      if (!ok) return;
      cart.clear();
    }
    cart.add(r, d);
    if (context.mounted) toast(context, '✅ تمت إضافة ${d.name}');
  }

  @override
  Widget build(BuildContext context) {
    final open = r.isOpenNow;
    final items = r.items;
    final cats = r.categories;

    final children = <Widget>[];
    Widget tile(Dish d) => Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Pic(src: d.image, emoji: d.emoji, size: 56, radius: 10),
            title: Text(d.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(
              [if (d.desc.isNotEmpty) d.desc, '${fmt(d.price)} د.ع'].join('\n'),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            isThreeLine: d.desc.isNotEmpty,
            trailing: d.available
                ? IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: kPrimary),
                    onPressed: () => _add(context, d),
                    icon: const Icon(Icons.add),
                  )
                : const Text('نفذ', style: TextStyle(color: Colors.red)),
          ),
        );

    final used = <Dish>{};
    for (final c in cats) {
      final l = items.where((d) => d.category == c.id).toList();
      if (l.isEmpty) continue;
      used.addAll(l);
      children.add(Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 6),
        child: Text(c.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ));
      children.addAll(l.map(tile));
    }
    final rest = items.where((d) => !used.contains(d)).toList();
    if (rest.isNotEmpty) {
      if (used.isNotEmpty) {
        children.add(const Padding(
          padding: EdgeInsets.fromLTRB(4, 12, 4, 6),
          child: Text('أخرى', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ));
      }
      children.addAll(rest.map(tile));
    }
    if (items.isEmpty) {
      children.add(const Padding(
        padding: EdgeInsets.all(30),
        child: Center(child: Text('لا توجد أصناف بعد')),
      ));
    }

    return Scaffold(
      appBar: AppBar(title: Text(r.name)),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              Pic(src: r.image, emoji: r.emoji, size: 80),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.rating > 0
                        ? '⭐ ${r.rating.toStringAsFixed(1)} (${r.ratingCount})'
                        : 'جديد'),
                    if (r.area.isNotEmpty || r.address.isNotEmpty)
                      Text('📍 ${[r.area, r.address].where((e) => e.isNotEmpty).join(' · ')}',
                          style: const TextStyle(fontSize: 13)),
                    Text('⏱️ ${r.time} دقيقة', style: const TextStyle(fontSize: 13)),
                    Text(open ? '● مفتوح الآن' : '● مغلق حالياً',
                        style: TextStyle(
                            color: open ? Colors.green.shade700 : Colors.red,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
          if (!open && toS(r.raw['openTime']).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('يفتح الساعة ${r.raw['openTime']}',
                  style: const TextStyle(color: Colors.black54)),
            ),
          ...children,
          const SizedBox(height: 80),
        ],
      ),
      floatingActionButton: AnimatedBuilder(
        animation: Cart.instance,
        builder: (_, __) {
          if (Cart.instance.isEmpty) return const SizedBox.shrink();
          return FloatingActionButton.extended(
            backgroundColor: kPrimary,
            foregroundColor: Colors.white,
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CartScreen())),
            icon: const Icon(Icons.shopping_cart),
            label: Text('السلة · ${fmt(Cart.instance.subtotal)} د.ع'),
          );
        },
      ),
    );
  }
}
