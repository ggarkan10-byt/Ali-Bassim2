import 'package:flutter/material.dart';

import '../common.dart';
import '../models.dart';
import '../services.dart';
import 'cart_screen.dart';
import 'orders_screen.dart';
import 'restaurant_screen.dart';
import 'taxi_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const FoodTab(),
      const TaxiScreen(),
      const OrdersTab(),
      const AccountTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ديوان', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          AnimatedBuilder(
            animation: Cart.instance,
            builder: (_, __) {
              final n = Cart.instance.count;
              return IconButton(
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => const CartScreen())),
                icon: Badge(
                  isLabelVisible: n > 0,
                  label: Text('$n'),
                  child: const Icon(Icons.shopping_cart_outlined),
                ),
              );
            },
          ),
        ],
      ),
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.restaurant), label: 'مطاعم'),
          NavigationDestination(icon: Icon(Icons.local_taxi), label: 'تكسي'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'طلباتي'),
          NavigationDestination(icon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

// ───────── المطاعم ─────────
class FoodTab extends StatefulWidget {
  const FoodTab({super.key});

  @override
  State<FoodTab> createState() => _FoodTabState();
}

class _FoodTabState extends State<FoodTab> {
  late final Stream<List<Restaurant>> _stream;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _stream = restaurantsStream();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'ابحث عن مطعم أو نوع أكل...',
              prefixIcon: Icon(Icons.search),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _q = v.trim()),
          ),
        ),
        Expanded(
          child: StreamBuilder<List<Restaurant>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('تعذّر تحميل المطاعم\n${snap.error}',
                        textAlign: TextAlign.center),
                  ),
                );
              }
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              var list = snap.data!.toList();
              if (_q.isNotEmpty) {
                list = list
                    .where((r) => r.name.contains(_q) || r.category.contains(_q))
                    .toList();
              }
              list.sort((a, b) {
                final ao = a.isOpenNow, bo = b.isOpenNow;
                if (ao != bo) return ao ? -1 : 1;
                final c = b.rating.compareTo(a.rating);
                if (c != 0) return c;
                return b.ratingCount.compareTo(a.ratingCount);
              });
              if (list.isEmpty) {
                return const Center(child: Text('لا توجد مطاعم'));
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                itemCount: list.length,
                itemBuilder: (_, i) => _RestCard(list[i]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _RestCard extends StatelessWidget {
  final Restaurant r;
  const _RestCard(this.r);

  @override
  Widget build(BuildContext context) {
    final open = r.isOpenNow;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => RestaurantScreen(r))),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Pic(src: r.image, emoji: r.emoji, size: 72),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.name,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 3),
                    Text(
                      [
                        if (r.category.isNotEmpty) r.category,
                        r.rating > 0 ? '⭐ ${r.rating.toStringAsFixed(1)}' : 'جديد',
                      ].join(' · '),
                      style: const TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                    const SizedBox(height: 3),
                    Text('⏱️ ${r.time} دقيقة',
                        style: const TextStyle(color: Colors.black54, fontSize: 12)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: open ? const Color(0xFFE6F6EA) : const Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(open ? 'مفتوح' : 'مغلق',
                    style: TextStyle(
                        fontSize: 12,
                        color: open ? Colors.green.shade800 : Colors.black54)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────── حسابي ─────────
class AccountTab extends StatefulWidget {
  const AccountTab({super.key});

  @override
  State<AccountTab> createState() => _AccountTabState();
}

class _AccountTabState extends State<AccountTab> {
  final _name = TextEditingController();
  final _phone = TextEditingController();

  @override
  void initState() {
    super.initState();
    Profile.load().then((p) {
      if (!mounted) return;
      _name.text = p.$1;
      _phone.text = p.$2;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final u = AuthService.user;
    final guest = u == null || u.isAnonymous;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(guest ? 'زائر' : (u?.displayName ?? u?.email ?? 'حسابي')),
          subtitle: Text(guest ? 'سجّل الدخول بـ Google لحفظ طلباتك' : (u?.email ?? '')),
        ),
        const SizedBox(height: 8),
        TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم')),
        const SizedBox(height: 10),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'رقم الهاتف'),
        ),
        const SizedBox(height: 10),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: kPrimary),
          onPressed: () async {
            await Profile.save(_name.text.trim(), _phone.text.trim());
            if (context.mounted) toast(context, 'تم الحفظ');
          },
          child: const Text('حفظ'),
        ),
        const Divider(height: 36),
        if (guest)
          OutlinedButton(
            onPressed: () async {
              final e = await AuthService.signInGoogle();
              if (e != null && context.mounted) toast(context, e);
            },
            child: const Text('الدخول بحساب Google'),
          ),
        OutlinedButton(
          onPressed: () async {
            final ok = await confirmDialog(context, 'تسجيل الخروج', 'هل تريد تسجيل الخروج؟');
            if (ok) await AuthService.signOut();
          },
          child: const Text('تسجيل الخروج'),
        ),
        const SizedBox(height: 10),
        TextButton(
          style: TextButton.styleFrom(foregroundColor: Colors.red),
          onPressed: () async {
            final ok = await confirmDialog(
              context,
              'حذف الحساب نهائياً',
              'سيتم إخفاء بياناتك من طلباتك وحذف حسابك ولا يمكن التراجع.',
              ok: 'حذف',
            );
            if (!ok) return;
            final err = await deleteMyAccount();
            if (err != null && context.mounted) toast(context, err);
          },
          child: const Text('حذف حسابي نهائياً'),
        ),
      ],
    );
  }
}
