import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../common.dart';
import '../services.dart';
import 'orders_screen.dart';

class TaxiScreen extends StatefulWidget {
  const TaxiScreen({super.key});

  @override
  State<TaxiScreen> createState() => _TaxiScreenState();
}

class _TaxiScreenState extends State<TaxiScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final MapController _mc = MapController();

  LatLng? _from;
  LatLng? _to;
  String _fromName = '';
  String _toName = '';
  bool _pickingFrom = true;
  double? _km;
  int _base = 0;
  bool _calc = false;
  bool _booking = false;

  bool _roundTrip = false;
  bool _stop = false;
  int _stopMin = 10;
  bool _parcels = false;

  @override
  void initState() {
    super.initState();
    Profile.load().then((p) {
      if (!mounted) return;
      _name.text = p.$1;
      _phone.text = p.$2;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  int get _price => _base == 0
      ? 0
      : taxiFinalPrice(_base, roundTrip: _roundTrip, stopMinutes: _stop ? _stopMin : 0);

  Future<void> _onTap(LatLng p) async {
    if (_pickingFrom) {
      setState(() {
        _from = p;
        _fromName = '';
        _pickingFrom = false;
      });
      reverseGeocode(p).then((n) {
        if (mounted && _from == p) setState(() => _fromName = n);
      });
    } else {
      setState(() {
        _to = p;
        _toName = '';
      });
      reverseGeocode(p).then((n) {
        if (mounted && _to == p) setState(() => _toName = n);
      });
    }
    await _recalc();
  }

  Future<void> _recalc() async {
    final a = _from, b = _to;
    if (a == null || b == null) return;
    setState(() => _calc = true);
    final km = await roadDistanceKm(a, b);
    if (!mounted) return;
    setState(() {
      _km = km;
      _base = taxiBasePriceForKm(km);
      _calc = false;
    });
  }

  Future<void> _gps() async {
    final p = await currentLocation();
    if (!mounted) return;
    if (p == null) {
      toast(context, 'تعذّر تحديد موقعك، فعّل الموقع أو اختر من الخريطة');
      return;
    }
    _mc.move(p, 15);
    setState(() => _pickingFrom = true);
    await _onTap(p);
  }

  Future<void> _book() async {
    final f = _from, t = _to;
    if (f == null) {
      toast(context, '📍 حدد نقطة الانطلاق على الخريطة');
      return;
    }
    if (t == null) {
      toast(context, '🏁 حدد الوجهة على الخريطة');
      return;
    }
    if (_base == 0 || _calc) {
      toast(context, '⏳ جاري حساب السعر...');
      return;
    }
    final name = _name.text.trim(), phone = _phone.text.trim();
    if (name.isEmpty) {
      toast(context, '⚠️ يرجى إدخال اسمك');
      return;
    }
    if (phone.length < 10) {
      toast(context, '⚠️ يرجى إدخال رقم هاتفك');
      return;
    }
    setState(() => _booking = true);
    await Profile.save(name, phone);

    final from = _fromName.isEmpty
        ? '${f.latitude.toStringAsFixed(5)}, ${f.longitude.toStringAsFixed(5)}'
        : _fromName;
    final to = _toName.isEmpty
        ? '${t.latitude.toStringAsFixed(5)}, ${t.longitude.toStringAsFixed(5)}'
        : _toName;
    final price = _price;
    final dist = _km != null ? '${_km!.toStringAsFixed(1)} كم' : '—';
    final serviceName = _parcels ? 'توصيل أغراض' : 'تكسي عادي';
    final opts = <String>[
      if (_roundTrip) 'ذهاب وإياب',
      if (_stop) 'توقف $_stopMin دقيقة',
      if (_parcels) 'توصيل أغراض',
    ];
    final od = <String, dynamic>{
      'type': 'taxi',
      'isTaxi': true,
      'from': from,
      'to': to,
      'taxiType': _parcels ? 'توصيل أغراض' : 'عادي',
      'serviceType': _parcels ? 'parcels' : 'passenger',
      'roundTrip': _roundTrip,
      'stopEnabled': _stop,
      'stopMinutes': _stop ? _stopMin : 0,
      'fareOptions': {
        'roundTrip': _roundTrip,
        'stopEnabled': _stop,
        'stopMinutes': _stop ? _stopMin : 0,
        'parcels': _parcels,
      },
      'total': price,
      'price': price,
      'driverFare': price,
      'distKm': _km,
      'fromLat': f.latitude,
      'fromLng': f.longitude,
      'toLat': t.latitude,
      'toLng': t.longitude,
      'customer': name,
      'phone': phone,
      'city': 'الديوانية',
      'takenBy': null,
      'status': 'waiting',
      'restName': serviceName,
      'address':
          '$dist — إلى: $to${opts.isNotEmpty ? ' — ${opts.join('، ')}' : ''}',
      'items': [
        {
          'emoji': _parcels ? '📦' : '🚕',
          'name': '$serviceName${opts.isNotEmpty ? ' · ${opts.join('، ')}' : ''} · $dist',
          'qty': 1,
          'price': price,
        }
      ],
    };
    final id = await Orders.save(od);
    if (!mounted) return;
    setState(() => _booking = false);
    if (id == null) {
      toast(context, '❌ تعذّر إرسال الطلب، تأكد من الاتصال وحاول مجدداً');
      return;
    }
    setState(() {
      _from = null;
      _to = null;
      _base = 0;
      _km = null;
      _pickingFrom = true;
    });
    Navigator.push(context, MaterialPageRoute(builder: (_) => TrackScreen(orderId: id)));
  }

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      if (_from != null)
        Marker(
          point: _from!,
          width: 40,
          height: 40,
          child: const Icon(Icons.trip_origin, color: Colors.green, size: 32),
        ),
      if (_to != null)
        Marker(
          point: _to!,
          width: 40,
          height: 40,
          child: const Icon(Icons.location_on, color: Colors.red, size: 38),
        ),
    ];
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        SizedBox(
          height: 300,
          child: Stack(
            children: [
              FlutterMap(
                mapController: _mc,
                options: MapOptions(
                  initialCenter: kCenter,
                  initialZoom: 14,
                  onTap: (_, p) => _onTap(p),
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'xyz.diwaniq.app',
                  ),
                  if (_from != null && _to != null)
                    PolylineLayer(polylines: [
                      Polyline(points: [_from!, _to!], strokeWidth: 4, color: kPrimary),
                    ]),
                  MarkerLayer(markers: markers),
                ],
              ),
              Positioned(
                top: 8,
                left: 8,
                right: 8,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        Expanded(
                          child: SegmentedButton<bool>(
                            segments: const [
                              ButtonSegment(value: true, label: Text('الانطلاق')),
                              ButtonSegment(value: false, label: Text('الوجهة')),
                            ],
                            selected: {_pickingFrom},
                            onSelectionChanged: (s) => setState(() => _pickingFrom = s.first),
                          ),
                        ),
                        IconButton(onPressed: _gps, icon: const Icon(Icons.my_location)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'من: ${_from == null ? 'اضغط على الخريطة لتحديد الانطلاق' : (_fromName.isEmpty ? '...' : _fromName)}',
              ),
              const SizedBox(height: 4),
              Text(
                'إلى: ${_to == null ? 'اضغط على الخريطة لتحديد الوجهة' : (_toName.isEmpty ? '...' : _toName)}',
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ذهاب وإياب'),
                value: _roundTrip,
                onChanged: (v) => setState(() => _roundTrip = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('توقف أثناء الرحلة'),
                value: _stop,
                onChanged: (v) => setState(() => _stop = v),
              ),
              if (_stop)
                Row(
                  children: [
                    const Text('مدة التوقف'),
                    Expanded(
                      child: Slider(
                        min: 10,
                        max: 60,
                        divisions: 5,
                        label: '$_stopMin دقيقة',
                        value: _stopMin.toDouble(),
                        onChanged: (v) => setState(() => _stopMin = v.round()),
                      ),
                    ),
                    Text('$_stopMin د'),
                  ],
                ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('توصيل أغراض'),
                value: _parcels,
                onChanged: (v) => setState(() => _parcels = v),
              ),
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم')),
              const SizedBox(height: 10),
              TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف'),
              ),
              const SizedBox(height: 14),
              Center(
                child: Text(
                  _calc
                      ? '⏳ جاري حساب الأجرة...'
                      : (_price > 0 ? 'أجرة الرحلة: ${fmt(_price)} د.ع' : 'حدّد الانطلاق والوجهة لمعرفة الأجرة'),
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: kPrimary),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: kPrimary, padding: const EdgeInsets.all(14)),
                onPressed: (_booking || _calc) ? null : _book,
                child: _booking
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('اطلب التكسي', style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
