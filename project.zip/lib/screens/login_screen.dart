import 'package:flutter/material.dart';

import '../common.dart';
import '../services.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _busy = false;
  String? _err;

  Future<void> _run(Future<String?> Function() f) async {
    setState(() {
      _busy = true;
      _err = null;
    });
    final e = await f();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _err = e;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('🍽️', style: TextStyle(fontSize: 72)),
                const SizedBox(height: 8),
                const Text('ديوان',
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: kPrimary)),
                const SizedBox(height: 6),
                const Text('توصيل طعام وتكسي في الديوانية',
                    style: TextStyle(fontSize: 15, color: Colors.black54)),
                const SizedBox(height: 36),
                if (_busy)
                  const CircularProgressIndicator()
                else ...[
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: kPrimary, padding: const EdgeInsets.all(14)),
                      onPressed: () => _run(AuthService.signInGoogle),
                      icon: const Icon(Icons.login),
                      label: const Text('الدخول بحساب Google', style: TextStyle(fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(14)),
                      onPressed: () => _run(AuthService.signInGuest),
                      child: const Text('المتابعة كزائر', style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ],
                if (_err != null) ...[
                  const SizedBox(height: 16),
                  Text(_err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
