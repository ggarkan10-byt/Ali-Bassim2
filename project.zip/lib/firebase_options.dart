// هذا الملف يُستبدل تلقائياً أثناء البناء (tool/prepare.py) من google-services.json
import 'package:firebase_core/firebase_core.dart';

const FirebaseOptions kFirebaseOptions = FirebaseOptions(
  apiKey: 'PLACEHOLDER',
  appId: 'PLACEHOLDER',
  messagingSenderId: 'PLACEHOLDER',
  projectId: 'safra2-8fc3c',
);

const String kWebClientId = '';
