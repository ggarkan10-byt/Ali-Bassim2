import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

const Color kPrimary = Color(0xFFD95A00);
const Color kBg = Color(0xFFFFF8F2);

String fmt(num n) {
  final s = n.round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return b.toString();
}

void toast(BuildContext c, String msg) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg, textAlign: TextAlign.center)));
}

Future<bool> confirmDialog(BuildContext c, String title, String body,
    {String ok = 'تأكيد', String cancel = 'رجوع'}) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(cancel)),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(ok)),
      ],
    ),
  );
  return r == true;
}

/// صورة من رابط أو data:base64، وإلا إيموجي
class Pic extends StatelessWidget {
  final String src;
  final String emoji;
  final double size;
  final double radius;
  const Pic({super.key, required this.src, required this.emoji, this.size = 64, this.radius = 14});

  @override
  Widget build(BuildContext context) {
    Widget fallback() => Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFFFE9D6),
            borderRadius: BorderRadius.circular(radius),
          ),
          child: Text(emoji, style: TextStyle(fontSize: size * 0.5)),
        );
    if (src.isEmpty) return fallback();
    Widget img;
    try {
      if (src.startsWith('data:')) {
        final Uint8List bytes = base64Decode(src.substring(src.indexOf(',') + 1));
        img = Image.memory(bytes,
            width: size, height: size, fit: BoxFit.cover, gaplessPlayback: true,
            errorBuilder: (_, __, ___) => fallback());
      } else if (src.startsWith('http')) {
        img = Image.network(src,
            width: size, height: size, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => fallback());
      } else {
        return fallback();
      }
    } catch (_) {
      return fallback();
    }
    return ClipRRect(borderRadius: BorderRadius.circular(radius), child: img);
  }
}

/// شاشة اختيار موقع على الخريطة، تعيد LatLng
class MapPicker extends StatefulWidget {
  final String title;
  final LatLng? initial;
  const MapPicker({super.key, required this.title, this.initial});

  @override
  State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  late LatLng _center;
  final MapController _mc = MapController();

  @override
  void initState() {
    super.initState();
    _center = widget.initial ?? const LatLng(31.9886, 44.9290);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mc,
            options: MapOptions(
              initialCenter: _center,
              initialZoom: 15,
              onPositionChanged: (pos, _) {
                _center = pos.center;
              },
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'xyz.diwaniq.app',
              ),
            ],
          ),
          const IgnorePointer(
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 40),
                child: Icon(Icons.location_on, size: 48, color: kPrimary),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 20,
            child: FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: kPrimary, padding: const EdgeInsets.all(14)),
              onPressed: () => Navigator.pop(context, _center),
              child: const Text('تأكيد هذا الموقع', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}
