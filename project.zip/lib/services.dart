import 'dart:convert';
import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'models.dart';
import 'zones.dart';

// ───────── ثوابت التسعير (نفس تطبيق الويب) ─────────
const int kDeliveryMin = 500;
const int kDeliveryMax = 5000;
const int kDeliveryPerKm = 185;
const int kTaxiBase = 1500;
const int kTaxiPerKm = 250;
const LatLng kCenter = LatLng(31.9886, 44.9290); // مركز الديوانية

final FirebaseFirestore db = FirebaseFirestore.instance;

// ───────── دوال جغرافية ─────────
double haversineKm(double lat1, double lon1, double lat2, double lon2) {
  const r = 6371.0;
  final dLat = (lat2 - lat1) * math.pi / 180;
  final dLon = (lon2 - lon1) * math.pi / 180;
  final a = math.pow(math.sin(dLat / 2), 2) +
      math.cos(lat1 * math.pi / 180) *
          math.cos(lat2 * math.pi / 180) *
          math.pow(math.sin(dLon / 2), 2);
  return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

int roundUp250(num amount) {
  if (amount <= 0) return 0;
  return ((amount / 250).ceil()) * 250;
}

bool _inRing(List<List<double>> p, double lat, double lng) {
  var c = false;
  final n = p.length;
  var j = n - 1;
  for (var i = 0; i < n; j = i++) {
    final xi = p[i][0], yi = p[i][1], xj = p[j][0], yj = p[j][1];
    if (((yi > lat) != (yj > lat)) &&
        (lng < (xj - xi) * (lat - yi) / (yj - yi) + xi)) {
      c = !c;
    }
  }
  return c;
}

double _edgeKm(List<List<double>> p, double lat, double lng) {
  final kx = 111.32 * math.cos(lat * math.pi / 180);
  const ky = 110.57;
  var best = 1e9;
  final n = p.length;
  var j = n - 1;
  for (var i = 0; i < n; j = i++) {
    final ax = (p[j][0] - lng) * kx, ay = (p[j][1] - lat) * ky;
    final bx = (p[i][0] - lng) * kx, by = (p[i][1] - lat) * ky;
    final dx = bx - ax, dy = by - ay;
    final l = dx * dx + dy * dy;
    final t = l == 0 ? 0.0 : math.max(0.0, math.min(1.0, -(ax * dx + ay * dy) / l));
    final px = ax + t * dx, py = ay + t * dy;
    final d = math.sqrt(px * px + py * py);
    if (d < best) best = d;
  }
  return best;
}

/// هل النقطة داخل محافظة الديوانية (منطقة عمل التوصيل)؟
bool inZone(double lat, double lng) {
  for (final z in kZones) {
    if (_inRing(z, lat, lng)) return true;
  }
  for (final z in kZones) {
    if (_edgeKm(z, lat, lng) <= 2) return true;
  }
  return false;
}

/// مسافة الطريق (كم) عبر OSRM، وإلا خط مستقيم × 1.35
Future<double> roadDistanceKm(LatLng a, LatLng b) async {
  try {
    final url = 'https://router.project-osrm.org/route/v1/driving/'
        '${a.longitude},${a.latitude};${b.longitude},${b.latitude}?overview=false';
    final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 7));
    if (r.statusCode == 200) {
      final j = jsonDecode(r.body);
      if (j['code'] == 'Ok' && j['routes'] is List && (j['routes'] as List).isNotEmpty) {
        return toD(j['routes'][0]['distance']) / 1000;
      }
    }
  } catch (_) {}
  return haversineKm(a.latitude, a.longitude, b.latitude, b.longitude) * 1.35;
}

int deliveryFeeForKm(double km) {
  final d = math.max(0.3, km);
  final raw = (kDeliveryMin + d * kDeliveryPerKm).round();
  return math.min(kDeliveryMax, math.max(kDeliveryMin, roundUp250(raw)));
}

int taxiBasePriceForKm(double km) {
  final d = math.max(0.5, km);
  final raw = d <= 2 ? kTaxiBase : (kTaxiBase + d * kTaxiPerKm).round();
  return roundUp250(raw);
}

/// السعر النهائي للتكسي بعد الخيارات (ذهاب وإياب / توقف)
int taxiFinalPrice(int base, {required bool roundTrip, required int stopMinutes}) {
  final trip = roundTrip ? base * 2 : base;
  final stopFee = stopMinutes > 0 ? (stopMinutes / 10 * 500) : 0;
  return roundUp250(trip + stopFee);
}

Future<LatLng?> currentLocation() async {
  try {
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return null;
    }
    final p = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 10),
      ),
    );
    return LatLng(p.latitude, p.longitude);
  } catch (_) {
    return null;
  }
}

// ───────── الحساب ─────────
class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static User? get user => _auth.currentUser;
  static String? get uid => _auth.currentUser?.uid;
  static Stream<User?> get changes => _auth.authStateChanges();

  static Future<String?> signInGuest() async {
    try {
      await _auth.signInAnonymously();
      return null;
    } on FirebaseAuthException catch (e) {
      return e.message ?? e.code;
    } catch (e) {
      return e.toString();
    }
  }

  static Future<String?> signInGoogle() async {
    try {
      final g = GoogleSignIn(
        serverClientId: kWebClientId.isEmpty ? null : kWebClientId,
      );
      final acc = await g.signIn();
      if (acc == null) return 'تم إلغاء تسجيل الدخول';
      final a = await acc.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: a.accessToken,
        idToken: a.idToken,
      );
      await _auth.signInWithCredential(cred);
      return null;
    } on FirebaseAuthException catch (e) {
      return e.message ?? e.code;
    } catch (e) {
      return e.toString();
    }
  }

  static Future<void> signOut() async {
    try {
      await GoogleSignIn().signOut();
    } catch (_) {}
    await _auth.signOut();
    final sp = await SharedPreferences.getInstance();
    await sp.remove('cust_name');
    await sp.remove('cust_phone');
  }
}

// ───────── بيانات الزبون المحفوظة محلياً ─────────
class Profile {
  static Future<(String, String)> load() async {
    final sp = await SharedPreferences.getInstance();
    return (sp.getString('cust_name') ?? '', sp.getString('cust_phone') ?? '');
  }

  static Future<void> save(String name, String phone) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('cust_name', name);
    await sp.setString('cust_phone', phone);
  }
}

// ───────── السلة ─────────
class Cart extends ChangeNotifier {
  static final Cart instance = Cart._();
  Cart._();

  Restaurant? restaurant;
  final List<CartLine> lines = [];
  Coupon? coupon;

  bool get isEmpty => lines.isEmpty;
  int get count => lines.fold(0, (s, l) => s + l.qty);
  int get subtotal => lines.fold(0, (s, l) => s + l.item.price * l.qty);

  /// يعيد false إذا كانت السلة لمطعم آخر (يجب سؤال المستخدم)
  bool canAddFrom(Restaurant r) =>
      lines.isEmpty || restaurant == null || restaurant!.id == r.id;

  void clear() {
    lines.clear();
    restaurant = null;
    coupon = null;
    notifyListeners();
  }

  void add(Restaurant r, Dish item) {
    if (!canAddFrom(r)) return;
    restaurant = r;
    final i = lines.indexWhere((l) => l.item.name == item.name);
    if (i >= 0) {
      lines[i].qty++;
    } else {
      lines.add(CartLine(item, 1));
    }
    _revalidate();
    notifyListeners();
  }

  void dec(CartLine l) {
    l.qty--;
    if (l.qty <= 0) lines.remove(l);
    if (lines.isEmpty) {
      restaurant = null;
      coupon = null;
    }
    _revalidate();
    notifyListeners();
  }

  void inc(CartLine l) {
    l.qty++;
    _revalidate();
    notifyListeners();
  }

  void _revalidate() {
    final c = coupon;
    if (c == null) return;
    if (c.minOrder > 0 && subtotal < c.minOrder) coupon = null;
  }

  /// يعيد رسالة خطأ أو null عند النجاح
  Future<String?> applyCoupon(String raw) async {
    final code = raw.replaceAll(RegExp(r'[\s‎‏]'), '').toUpperCase();
    if (code.isEmpty) return 'أدخل كود الخصم أولاً';
    if (lines.isEmpty) return 'السلة فارغة';
    try {
      final snap =
          await db.collection('coupons').where('code', isEqualTo: code).get();
      if (snap.docs.isEmpty) return 'كود الخصم غير صحيح';
      final d = snap.docs.first.data();
      final now = DateTime.now();
      final type = toS(d['type']).toLowerCase();
      final value = toD(d['value']);
      if (d['active'] == false) return 'كود الخصم غير مفعّل';
      if (!['percent', 'fixed', 'free_delivery'].contains(type) ||
          (type != 'free_delivery' && value <= 0)) {
        return 'كود الخصم غير صالح';
      }
      final st = toDate(d['startsAt']);
      final ex = toDate(d['expiresAt']);
      if (st != null && st.isAfter(now)) return 'كود الخصم لم يبدأ بعد';
      if (ex != null && ex.isBefore(now)) return 'انتهت صلاحية كود الخصم';
      final lim = toI(d['usageLimit']);
      if (lim > 0 && toI(d['usedCount']) >= lim) {
        return 'تم استخدام هذا الكود بالكامل';
      }
      final rid = toS(d['restId']);
      if (rid.isNotEmpty && rid != restaurant?.id) {
        return 'هذا الكود لا ينطبق على هذا المطعم';
      }
      final mo = toI(d['minOrder']);
      if (mo > 0 && subtotal < mo) return 'الحد الأدنى للطلب لاستخدام الكود $mo د.ع';
      coupon = Coupon(
        code: code,
        type: type,
        value: value,
        maxDiscount: toI(d['maxDiscount']),
        minOrder: mo,
        restId: rid,
      );
      notifyListeners();
      return null;
    } catch (_) {
      return 'تعذّر التحقق من الكود الآن، حاول مجدداً';
    }
  }

  void removeCoupon() {
    coupon = null;
    notifyListeners();
  }
}

// ───────── الطلبات ─────────
class Orders {
  /// طلبات الزبون الحالية (تُرتب محلياً حسب الأحدث)
  static Stream<List<Map<String, dynamic>>> mine() {
    final uid = AuthService.uid;
    if (uid == null) return const Stream.empty();
    return db
        .collection('orders')
        .where('customerUid', isEqualTo: uid)
        .snapshots()
        .map((s) {
      final l = s.docs.map((d) => {'id': d.id, ...d.data()}).toList();
      l.sort((a, b) {
        final da = toDate(a['createdAt'])?.millisecondsSinceEpoch ?? 1 << 50;
        final dbb = toDate(b['createdAt'])?.millisecondsSinceEpoch ?? 1 << 50;
        return dbb.compareTo(da);
      });
      return l;
    });
  }

  static Stream<Map<String, dynamic>?> one(String id) => db
      .collection('orders')
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? {'id': d.id, ...d.data()!} : null);

  static Future<String?> save(Map<String, dynamic> data) async {
    try {
      final ref = await db.collection('orders').add({
        ...data,
        'customerUid': AuthService.uid,
        'timestamp': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
        'status': 'waiting',
        'takenBy': null,
        'city': 'الديوانية',
      });
      return ref.id;
    } catch (e) {
      debugPrint('saveOrder failed: $e');
      return null;
    }
  }

  static Future<void> cancel(String id) async {
    final ref = db.collection('orders').doc(id);
    var hasDriver = false;
    try {
      final d = (await ref.get()).data();
      final tb = d?['takenBy'];
      hasDriver = tb != null && tb != 'cancelled';
    } catch (_) {}
    final upd = <String, dynamic>{
      'status': 'cancelled',
      'cancelledAt': FieldValue.serverTimestamp(),
      'cancelledBy': 'customer',
    };
    if (!hasDriver) upd['takenBy'] = 'cancelled';
    await ref.update(upd);
  }

  static Future<bool> rate(
      String restId, String restName, String orderId, int stars) async {
    try {
      await db.collection('ratings').add({
        'restId': restId,
        'restName': restName,
        'orderId': orderId,
        'rating': stars,
        'createdAt': FieldValue.serverTimestamp(),
      });
      try {
        final ref = db.collection('restaurants').doc(restId);
        final d = (await ref.get()).data();
        if (d != null) {
          final oldAvg = toD(d['rating']);
          final oldCount = toI(d['ratingCount']);
          final n = oldCount + 1;
          final avg = oldCount > 0 ? (oldAvg * oldCount + stars) / n : stars.toDouble();
          await ref.update({
            'rating': double.parse(avg.toStringAsFixed(1)),
            'ratingCount': n,
          });
        }
      } catch (_) {}
      return true;
    } catch (_) {
      return false;
    }
  }
}

Stream<List<Restaurant>> restaurantsStream() => db
    .collection('restaurants')
    .where('status', whereIn: ['open', 'approved', 'closed'])
    .snapshots()
    .map((s) => s.docs.map((d) => Restaurant(d.id, d.data())).toList());

/// اسم المكان من الإحداثيات (Nominatim) وإلا الإحداثيات نفسها
Future<String> reverseGeocode(LatLng p) async {
  final fallback = '${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)}';
  try {
    final url = 'https://nominatim.openstreetmap.org/reverse?lat=${p.latitude}'
        '&lon=${p.longitude}&format=json&accept-language=ar&zoom=18';
    final r = await http
        .get(Uri.parse(url), headers: {'User-Agent': 'DiwanApp/1.0 (xyz.diwaniq.app)'})
        .timeout(const Duration(seconds: 6));
    if (r.statusCode == 200) {
      final j = jsonDecode(r.body);
      final a = j['address'];
      if (a is Map) {
        final parts = <String>[];
        for (final k in ['road', 'neighbourhood', 'suburb', 'city_district', 'city', 'town']) {
          final v = a[k];
          if (v is String && v.isNotEmpty && !parts.contains(v)) parts.add(v);
          if (parts.length >= 2) break;
        }
        if (parts.isNotEmpty) return parts.join('، ');
      }
      final dn = j['display_name'];
      if (dn is String && dn.isNotEmpty) return dn.split(',').take(2).join('،').trim();
    }
  } catch (_) {}
  return fallback;
}

/// حذف الحساب: إخفاء بيانات الزبون من طلباته ثم حذف حساب Firebase
/// يعيد null عند النجاح أو رسالة خطأ.
Future<String?> deleteMyAccount() async {
  final uid = AuthService.uid;
  final u = AuthService.user;
  if (uid == null || u == null) return 'لا يوجد حساب';
  const finalSt = [
    'delivered', 'completed', 'done', 'finished', 'taxi_delivered',
    'taxi_completed', 'taxi_done', 'cancelled', 'rejected'
  ];
  try {
    final snap = await db.collection('orders').where('customerUid', isEqualTo: uid).get();
    final todo = <Map<String, dynamic>>[];
    var busy = 0;
    for (final d in snap.docs) {
      final x = d.data();
      if (finalSt.contains(toS(x['status']))) {
        todo.add({'id': d.id, 'cancel': false});
      } else if (x['takenBy'] != null) {
        busy++;
      } else {
        todo.add({'id': d.id, 'cancel': true});
      }
    }
    if (busy > 0) return 'عندك طلب جارٍ مع سائق، انتظر اكتماله ثم احذف الحساب';
    final scrub = <String, dynamic>{
      'customer': '', 'customerPhone': '', 'phone': '', 'address': '',
      'notes': '', 'location': null, 'custLat': null, 'custLng': null,
      'lat': null, 'lng': null, 'fromLat': null, 'fromLng': null,
      'toLat': null, 'toLng': null, 'from': '', 'to': '', 'deletedAccount': true,
    };
    for (final t in todo) {
      final ref = db.collection('orders').doc(t['id'] as String);
      if (t['cancel'] == true) {
        await ref.update({
          'status': 'cancelled',
          'takenBy': 'cancelled',
          'cancelledAt': FieldValue.serverTimestamp(),
        });
      }
      await ref.update(scrub);
    }
    try {
      await u.delete();
    } on FirebaseAuthException catch (e) {
      if (e.code == 'requires-recent-login') {
        return 'لأسباب أمنية سجّل خروج ثم ادخل من جديد وأعد المحاولة';
      }
      return e.message ?? e.code;
    }
    final sp = await SharedPreferences.getInstance();
    await sp.clear();
    return null;
  } catch (e) {
    return 'تعذّر حذف الحساب: $e';
  }
}
